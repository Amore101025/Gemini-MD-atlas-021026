# FormAgent AI: Technical Specification Document

**Version:** 1.1.0  
**Date:** February 10, 2026  
**Status:** Approved  
**Author:** Senior Frontend Engineering Team

---

## 1. Executive Summary

**FormAgent AI** is a next-generation "Agentic AI" system designed to bridge the gap between unstructured application requirements (text, markdown, legacy documents) and structured, executable digital forms. 

Traditionally, converting a text-based application form into a dynamic PDF requires manual usage of tools like Adobe Acrobat Pro or writing complex scripts. FormAgent AI automates this by employing Large Language Models (LLMs) to parse natural language documents or structured specifications, extract form schema, and generate two distinct artifacts:
1. A **Python script** utilizing the `fpdf2` library to programmatically generate the PDF.
2. A **Live Preview** and downloadable client-side PDF utilizing `jsPDF` for immediate user verification.

This document serves as the comprehensive technical guide for the architecture, user interface design, data modeling, and service integration of the FormAgent AI platform.

---

## 2. System Overview

### 2.1 Core Value Proposition
The system allows users to upload or paste application forms in raw text formats or structured markdown specifications. It utilizes Google's Gemini API to perform semantic analysis, identifying fields such as text inputs, checkboxes, dropdowns, and date selectors. The system then acts as a dual-generator:
- **Immediate Mode:** Generates a visual preview and a browser-generated PDF for quick testing.
- **Developer Mode:** Generates high-quality Python code using the `fpdf2` library, which developers can use to deploy scalable PDF generation pipelines.

### 2.2 Scope
The current iteration (v1.1) focuses on:
- Parsing `.txt` and `.md` inputs in two distinct modes: **Raw Document** and **PDF Spec**.
- Identifying four primary field types: Text, Checkbox, Dropdown, Date.
- Generating valid Python syntax for `fpdf2`.
- Generating valid browser-based PDFs via `jsPDF`.
- Providing a split-view interactive UI for editing the detected structure.
- **New in v1.1**: Default "PDF Spec" workflow for structured form definitions.

---

## 3. Architecture & Technology Stack

The application is built as a Single Page Application (SPA) to ensure responsiveness and immediate feedback. It relies on a client-centric architecture where the browser handles UI state, while heavy semantic lifting is offloaded to the Gemini API.

### 3.1 Frontend Framework
- **React 19**: Selected for its robust component model and latest hook improvements. We utilize functional components with hooks (`useState`, `useEffect`, `useRef`) for state management.
- **TypeScript**: Enforced throughout the codebase to ensure type safety, particularly for the dynamic form structures returned by the AI.

### 3.2 Styling System
- **Tailwind CSS**: Utility-first CSS framework allows for rapid UI development with consistent spacing, typography, and color scales.
- **Lucide React**: A lightweight, consistent icon set used to enhance UI usability (e.g., indicating download actions, field types, and processing states).

### 3.3 AI Integration Layer
- **Google Gemini API**: Accessed via the `@google/genai` SDK.
- **Model**: `gemini-3-flash-preview` is chosen for its low latency and high capability in JSON extraction and code generation tasks.
- **Transport**: JSON-over-HTTP via the SDK.

### 3.4 PDF Engines
- **Client-Side Engine (jsPDF)**: Used for the "Preview PDF" feature. It runs entirely in the browser, manipulating the DOM Canvas API and generating raw PDF bytes for immediate download.
- **Agentic Engine (fpdf2)**: This is a *conceptual* engine from the perspective of the web app. The app generates *code* for this engine, which is intended to be run in a Python environment by the end user.

---

## 4. Data Model & Type Definitions

The core of the application relies on a strict schema to translate unstructured text into structured data.

### 4.1 Field Types
We define an enum `FieldType` to strictly categorize input mechanisms.

```typescript
export enum FieldType {
  TEXT = 'text',
  CHECKBOX = 'checkbox',
  DROPDOWN = 'dropdown',
  DATE = 'date'
}
```

### 4.2 The Form Structure
The `FormStructure` interface is the "source of truth". It is what the AI is instructed to return, and what the UI renders.

```typescript
export interface FormField {
  id: string;             // Unique identifier for React keys and PDF AcroForm field names
  label: string;          // Human-readable label (e.g., "Device Name")
  name: string;           // Machine-readable variable name (e.g., "device_name")
  type: FieldType;        // The type of input
  options?: string[];     // Array of strings, exclusively for DROPDOWN types
  value?: string | boolean; // Default value (e.g., today's date, or pre-checked box)
  x?: number;             // Optional coordinate for advanced layout mapping
  y?: number;             // Optional coordinate for advanced layout mapping
  width?: number;         // Layout dimension
  height?: number;        // Layout dimension
}

export interface FormStructure {
  title: string;          // Title of the document
  fields: FormField[];    // Ordered list of fields
}
```

This structure is designed to be agnostic of the rendering engine. It can be fed into `jsPDF` for the web view or parsed by the Python code generator string template.

---

## 5. Component Architecture

The application layout is divided into a "Split Pane" design, optimizing for the "Source vs. Result" mental model.

### 5.1 Root Component (`App.tsx`)
The `App` component acts as the Orchestrator.
- **State**:
  - `inputMode`: 'raw' | 'spec'. Controls which input tab is active.
  - `rawText`: The raw natural language source string.
  - `specText`: The structured markdown source string (default active).
  - `structure`: The JSON object returned by Gemini.
  - `pythonCode`: The string containing the generated Python script.
  - `activeTab`: Controls whether the user sees the Visual Preview or the Code View.
  - `isAnalyzing`: Boolean flag for loading states.
- **Responsibilities**:
  - Initiates API calls via `GeminiService`.
  - Handles "Add/Update/Delete" actions from the preview and updates the `structure` state.
  - Triggers the file download workflows.

### 5.2 Header Component (`Header.tsx`)
A stateless functional component providing branding and status indication. It includes a visual indicator ("fpdf2 Agent Ready") to reassure the user that the system is operational.

### 5.3 Input Section (`InputSection.tsx`)
This component handles the "Source" data with a tabbed interface.
- **Features**:
  - **Input Modes**:
    - **Raw Document**: For pasting unstructured form text.
    - **PDF Spec**: For pasting structured markdown specifications (e.g., `## pdf_spec`).
  - **File Upload**: Accepts `.txt` and `.md` files via a hidden file input triggered by a styled button. It utilizes the File API to read text content asynchronously into the active tab.
  - **Text Area**: A controlled input allowing users to paste or edit the text directly.
  - **Action Button**: The "Generate Dynamic PDF" button. It features a loading spinner state to provide feedback during the asynchronous AI operation.
- **UX Detail**: The component disables the action button if the input is empty to prevent wasted API calls.

### 5.4 Form Preview (`FormPreview.tsx`)
This component renders the `structure` state into a visual HTML form.
- **Interactive Editing**: It provides UI controls (Trash icon) to remove fields that were incorrectly hallucinated or unwanted.
- **Field Rendering Logic**:
  - It iterates over `structure.fields`.
  - Based on `field.type`, it renders the corresponding HTML element (`<input>`, `<select>`, `<input type="checkbox">`).
  - **Note**: These HTML inputs are `disabled` by default or styled to look like a preview, as the user is not meant to *fill* the form here, but to *design* it. However, showing them as native controls gives the user an accurate representation of the final PDF utility.
- **Design**: Encapsulated in a paper-like container with shadows to simulate a physical document.

### 5.5 Code Preview (`CodePreview.tsx`)
A dedicated code viewer component.
- **Theme**: Uses a dark, IDE-like color scheme (grey-900 backgrounds) to distinguish it from the "document" view.
- **Functionality**:
  - Displays the raw string of the generated Python code.
  - Syntax Highlighting (simulated via basic color classes).
  - **Copy to Clipboard**: A utility button that writes the code string to the navigator clipboard for easy transfer to a local IDE.

---

## 6. Service Layer & AI Logic

The intelligence of FormAgent AI resides in the `GeminiService`. This service abstracts the complexity of prompt engineering and API communication.

### 6.1 `services/gemini.ts`

This module exposes two primary methods:

#### 6.1.1 `parseFormStructure(text: string)`
This function is responsible for the "Extraction" phase.
- **Model**: `gemini-3-flash-preview`.
- **Configuration**: Sets `responseMimeType: 'application/json'`. This is critical. It forces the model to output valid JSON, reducing parsing errors significantly compared to free-text parsing.
- **Prompt Strategy**:
  - **Role Definition**: "You are an expert data extraction agent."
  - **Context**: "Analyze the following document text and extract the structure for a fillable PDF form. The input might be a raw natural language document OR a structured markdown specification (e.g. starting with ## pdf_spec)."
  - **One-Shot/Few-Shot Learning**: The prompt includes specific examples of how to handle ambiguous text (e.g., 'Submission Type: [Option1]' -> Dropdown).
  - **Schema Definition**: The prompt explicitly defines the TypeScript interface the JSON must adhere to. This acts as a contract between the AI and the frontend code.

#### 6.1.2 `generatePythonCode(structure: FormStructure)`
This function is responsible for the "Generation" phase.
- **Input**: The verified, structured JSON object (not the raw text). This ensures the code generation is grounded in the structured data we have already validated.
- **Prompt Strategy**:
  - **Role Definition**: "You are a Python expert specializing in PDF generation using the 'fpdf2' library."
  - **Constraints**: 
    - Must import `fpdf` and `datetime`.
    - Must use specific methods like `pdf.form_text` and `pdf.form_combo`.
    - Must calculate layout coordinates (`x`, `y`) to ensure fields flow vertically without overlap.
  - **Output**: Requests raw Python code without Markdown formatting.

### 6.2 `services/pdfGenerator.ts`
This service handles client-side PDF generation using `jsPDF`.
- **Logic**: It maps the internal `FormStructure` to `jsPDF`'s AcroForm API.
- **Coordinate System**: It implements a simple layout engine that maintains a `currentY` cursor.
  - It starts at `y=40` (after the title).
  - For every field, it draws the Label text at `x=20`.
  - It draws the Input widget at `x=70`.
  - It increments `currentY` by `15` units after each field.
- **Field Mapping**:
  - `TEXT` -> `doc.addField(new TextField())`
  - `CHECKBOX` -> `doc.addField(new CheckBox())`
  - `DROPDOWN` -> `doc.addField(new ComboBox())`
- **Output**: Triggers a browser download of `dynamic_form.pdf`.

---

## 7. User Workflows

### 7.1 The Standard Creation Flow (v1.1 Spec Mode)
1.  **Ingestion**: The user lands on the page. The "PDF Spec" tab is active by default, pre-filled with a sample `## pdf_spec` markdown.
2.  **Analysis**: The user clicks "Generate Dynamic PDF".
    - The app enters `isAnalyzing` state.
    - `parseFormStructure` processes the structured spec.
    - Gemini returns a validated JSON object.
    - `setStructure` updates the state.
    - `generatePythonCode` is called.
    - `setPythonCode` updates.
    - `activeTab` switches to `PREVIEW`.
3.  **Verification**: The user sees the visual form in the right panel.
4.  **Export**:
    - The user clicks "PDF" to download the client-side version.
    - The user clicks ".py Script" to download the Python agent code.

### 7.2 The Raw Text Flow
1.  **Switch**: User clicks the "Raw Document" tab.
2.  **Ingestion**: User pastes unstructured text or uploads a `.txt` file.
3.  **Processing**: Identical to 7.1, but the prompt handles the unstructured nature of the input.

---

## 8. UI/UX Design Specifications

### 8.1 Visual Language
The design mimics a modern SaaS development tool (like Vercel or GitHub).
- **Primary Color**: Indigo-600 (`#4f46e5`). Used for primary actions and branding to convey trust and intelligence.
- **Backgrounds**:
  - Application background: Gray-50 (`#f9fafb`) to reduce eye strain.
  - Content Panels: White (`#ffffff`) with subtle gray borders (`border-gray-200`) and soft shadows (`shadow-sm`).
  - Code Panel: Dark Gray (`#1e1e1e`) to resemble VS Code.

### 8.2 Typography
- **Font Family**: System Sans-Serif (Inter/Roboto/San Francisco) via Tailwind's `font-sans`.
- **Code Font**: Monospace (`font-mono`) for the raw text input and the Python code preview.
- **Readability**: High contrast text (Gray-900 for headings, Gray-700 for labels) ensures accessibility.

### 8.3 Feedback Mechanisms
- **Loading States**: The "Generate" button transforms into a disabled state with a spinning CSS loader.
- **Empty States**: Both Input and Preview panels have dedicated empty states instructing the user on what to do next.
- **Hover Effects**: Interactive elements (buttons, trash icons) have `hover:` states (background color changes, scale transforms) to indicate interactivity.

### 8.4 Responsive Design
The app utilizes Flexbox for layout.
- **Desktop (>1024px)**: Side-by-side view. Input on Left (50%), Output on Right (50%).
- **Mobile/Tablet (<1024px)**: Stacked view. Input on top, Output on bottom.
- **Sticky Header**: The header remains fixed at the top to allow access to global status regardless of scroll position.

---

## 9. API & Security Considerations

### 9.1 API Key Management
The application expects the Gemini API key to be available in the environment as `process.env.API_KEY`.
- **Security Note**: In a production environment, exposing the API Key in a client-side React app is a security risk.
- **Mitigation (Production)**: In a real-world deployment, the `GeminiService` calls would be proxied through a lightweight backend (Next.js API Routes or Express) to keep the key secret. For this "Agentic AI" demo, direct client-side calls are used for architectural simplicity and portability.

### 9.2 Data Privacy
- No user data is persisted on any server database by the application itself.
- Data is transiently sent to Google's Gemini API for processing and is subject to Google's data processing terms.
- The state is held in the user's browser memory (RAM) and is cleared on page refresh.

---

## 10. Future Roadmap (v1.1+)

1.  **Two-Way Binding for Code Generation**: When a user manually adds/deletes a field in the UI, the Python code should automatically regenerate or "heal" to reflect these changes.
2.  **Advanced Field Types**: Support for Radio Buttons, Signature blocks, and File Upload attachments in the generated PDF.
3.  **Layout Customization**: AI-driven layout that isn't just a vertical stack. The AI could assign `(x, y)` coordinates to place "First Name" and "Last Name" on the same row.
4.  **Borb & ReportLab Support**: Add a dropdown to select the target Python library (fpdf2 vs borb) depending on the user's enterprise requirements.
5.  **Prompt Refinement**: Implement "Chain of Thought" prompting to handle highly complex, multi-page application forms.

---

## 11. Comprehensive Follow-Up Questions

Below are 20 questions designed to probe the scalability, security, and feature completeness of the FormAgent AI system as it moves toward production.

1.  **Prompt robustness**: How does the system handle extremely long input documents that exceed the token limit of the `gemini-3-flash-preview` model?
2.  **Schema validation**: Should we implement a Zod schema validation step on the client side to catch malformed JSON responses from the AI before they crash the React component?
3.  **Authentication**: If this tool is deployed internally, should we integrate SSO (Single Sign-On) to restrict who can generate API calls?
4.  **Error handling**: What is the fallback behavior if `fpdf2` is deprecated or changes its API significantly? Does the prompt need version pinning?
5.  **Layout complexity**: How can we support multi-column layouts (e.g., "City" and "Zip Code" side-by-side) instead of a purely vertical stack?
6.  **Field type expansion**: How do we plan to support "Radio Button Groups" which are semantically different from Dropdowns in PDF forms?
7.  **Signature handling**: Since digital signatures are complex, should we integrate a dedicated library like `pyHanko` in the generated Python code?
8.  **File uploads**: If a form requires a photo attachment, can the AI generate code to handle file embedding in the PDF?
9.  **State persistence**: Should we use `localStorage` to save the user's draft (raw text) so they don't lose work on a browser refresh?
10. **Code execution**: Is there value in adding a server-side Python sandbox (like Pyodide or a Docker container) to *run* the generated code and return the actual PDF file, rather than just the code?
11. **PDF Import**: Can we support *uploading* an existing PDF and using OCR (via Gemini 2.5 Flash) to reverse-engineer the specification?
12. **Localization**: How does the prompt need to change to support generating forms in languages with non-Latin scripts (e.g., Japanese, Arabic)?
13. **Accessibility**: Can the generated PDF include proper tagging (PDF/UA) for screen readers, and can the AI be prompted to include tooltips?
14. **Testing**: How do we automate the testing of the AI prompts? Do we need a dataset of "Golden Sample" inputs and outputs?
15. **Cost optimization**: Is `gemini-3-flash-preview` the most cost-effective model, or could we use a smaller, fine-tuned model for this specific JSON extraction task?
16. **Version control**: Should the generated Python code include a version header or hash to track which prompt version created it?
17. **Integration**: Can we provide a webhook URL so that when the form is designed, the JSON structure is POSTed to a customer's backend?
18. **Custom branding**: How can we allow users to upload a logo image that gets included in the generated Python code (e.g., as a base64 string)?
19. **Form logic**: Can the AI infer logic rules (e.g., "If 'Other' is selected, enable text field") and generate the corresponding JavaScript for the PDF?
20. **Analytics**: Should we track which field types are most commonly generated to inform future feature development?

---

## 12. Conclusion

FormAgent AI represents a significant leap in productivity for developers and administrators digitizing paperwork. By decoupling the extraction logic (AI) from the rendering logic (Python/JS), it provides a robust, verifiable, and editable workflow. The technical design prioritizes modularity, utilizing TypeScript interfaces to ensure that the AI's output is strictly typed and reliable before it ever reaches the rendering engine. This specification provides the blueprint for a scalable, high-quality "World Class" engineering solution.
