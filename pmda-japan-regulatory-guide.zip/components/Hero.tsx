import React from 'react';
import { ArrowRight, Activity } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative bg-slate-900 text-white overflow-hidden rounded-b-3xl shadow-xl">
      <div className="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80')] bg-cover bg-center" />
      <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/90 to-transparent" />
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="md:w-2/3 lg:w-1/2">
          <div className="flex items-center space-x-2 text-rose-500 font-bold tracking-wider uppercase mb-4">
            <Activity className="w-5 h-5" />
            <span>Japan Regulatory Factsheet</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight mb-6 leading-tight">
            Entering the Japanese Market:<br />
            <span className="text-rose-500">The PMD Act</span> Guide
          </h1>
          <p className="text-lg text-slate-300 mb-8 leading-relaxed">
            A comprehensive guide for medical device manufacturers navigating the Pharmaceutical and Medical Device Act (PMD Act). Understand classification, QMS Ordinance 169, and the vital role of the MAH.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <a href="#classifications" className="inline-flex items-center justify-center px-6 py-3 border border-transparent text-base font-medium rounded-lg text-white bg-rose-600 hover:bg-rose-700 transition-colors shadow-lg shadow-rose-900/20">
              Check Classification
            </a>
            <a href="#checklist" className="inline-flex items-center justify-center px-6 py-3 border border-slate-600 text-base font-medium rounded-lg text-slate-200 hover:bg-slate-800 transition-colors">
              View Checklist
              <ArrowRight className="ml-2 w-4 h-4" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;