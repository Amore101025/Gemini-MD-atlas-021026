import React from 'react';
import { processSteps } from '../content';
import { UserCheck, FileSearch, ShieldCheck, Send, Search, Rocket, LucideIcon } from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  UserCheck, FileSearch, ShieldCheck, Send, Search, Rocket
};

const ProcessTimeline: React.FC = () => {
  return (
    <div className="py-12">
      <div className="text-center mb-12">
        <h2 className="text-3xl font-bold text-slate-900">Route to Market</h2>
        <p className="mt-4 text-slate-600 max-w-2xl mx-auto">
          The PMD Act outlines a strict sequence of actions. Appointing an MAH is often the critical first step for foreign manufacturers.
        </p>
      </div>

      <div className="relative max-w-5xl mx-auto px-4">
        {/* Vertical Line for Desktop */}
        <div className="absolute left-1/2 transform -translate-x-1/2 top-0 bottom-0 w-0.5 bg-slate-200 hidden md:block" />

        <div className="space-y-12 relative">
          {processSteps.map((step, index) => {
            const Icon = iconMap[step.iconName];
            const isLeft = index % 2 === 0;

            return (
              <div key={index} className={`flex flex-col md:flex-row items-center ${isLeft ? 'md:flex-row-reverse' : ''}`}>
                
                {/* Content Side */}
                <div className="w-full md:w-1/2 md:px-8 mb-4 md:mb-0">
                  <div className={`bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow relative ${isLeft ? 'text-left' : 'text-left md:text-right'}`}>
                    <div className={`hidden md:block absolute top-1/2 transform -translate-y-1/2 w-4 h-4 bg-white border-2 border-slate-300 rounded-full z-10 ${isLeft ? '-right-[41px]' : '-left-[41px]'}`} />
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">{step.description}</p>
                  </div>
                </div>

                {/* Center Icon */}
                <div className="relative z-10 flex items-center justify-center w-12 h-12 bg-rose-600 rounded-full shadow-lg border-4 border-white shrink-0">
                  <Icon className="w-5 h-5 text-white" />
                </div>

                {/* Spacer Side */}
                <div className="w-full md:w-1/2 md:px-8 hidden md:block" />
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProcessTimeline;