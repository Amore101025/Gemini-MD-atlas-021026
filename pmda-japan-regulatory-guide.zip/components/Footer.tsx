import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 mt-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
        <div className="mb-4 md:mb-0">
          <h4 className="text-white font-bold text-lg">PMDA Regulatory Guide</h4>
          <p className="text-sm mt-1">Based on MHLW & PMDA guidance documents.</p>
        </div>
        <div className="text-sm text-center md:text-right">
          <p>© {new Date().getFullYear()} Regulatory Educational Resource.</p>
          <p className="mt-1 text-slate-500">Not official legal advice. Consult with a qualified MAH.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;