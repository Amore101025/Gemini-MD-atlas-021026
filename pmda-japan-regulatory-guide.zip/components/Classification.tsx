import React, { useState } from 'react';
import { classificationData } from '../content';
import { CheckCircle2, AlertCircle } from 'lucide-react';

const Classification: React.FC = () => {
  const [activeTab, setActiveTab] = useState(classificationData[0].id);

  const activeData = classificationData.find(d => d.id === activeTab) || classificationData[0];

  return (
    <div id="classifications" className="py-12 bg-white rounded-3xl shadow-sm border border-slate-200 my-8">
      <div className="px-6 md:px-12 mb-8">
        <h2 className="text-3xl font-bold text-slate-900 mb-2">Risk Classification</h2>
        <p className="text-slate-600">Japan uses a 4-tier risk system (Class I - IV) based on GHTF/IMDRF principles.</p>
      </div>

      <div className="flex flex-col md:flex-row px-6 md:px-12 gap-8">
        {/* Navigation Tabs */}
        <div className="flex md:flex-col gap-2 overflow-x-auto md:overflow-visible pb-4 md:pb-0 md:w-1/4">
          {classificationData.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`text-left px-4 py-4 rounded-xl transition-all duration-200 flex items-center justify-between group ${
                activeTab === item.id
                  ? 'bg-slate-900 text-white shadow-md'
                  : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
              }`}
            >
              <span className="font-semibold">{item.className}</span>
              <div className={`w-2 h-2 rounded-full ${activeTab === item.id ? 'bg-rose-500' : 'bg-slate-300'}`} />
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1 min-h-[300px]">
          <div className={`h-full rounded-2xl p-8 border ${activeData.color.replace('bg-', 'bg-opacity-10 ')}`}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-slate-900">{activeData.className}</h3>
              <span className={`px-3 py-1 rounded-full text-sm font-bold border ${activeData.color}`}>
                {activeData.riskLevel}
              </span>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h4 className="text-sm uppercase tracking-wide text-slate-500 font-semibold mb-3">Regulatory Pathway</h4>
                <div className="flex items-start gap-3 mb-6">
                  <CheckCircle2 className="w-6 h-6 text-slate-900 shrink-0" />
                  <div>
                    <p className="font-semibold text-lg text-slate-800">{activeData.approvalType}</p>
                    <p className="text-sm text-slate-600 mt-1">Review Authority: <span className="font-medium text-rose-600">{activeData.agency}</span></p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-sm uppercase tracking-wide text-slate-500 font-semibold mb-3">Common Examples</h4>
                <ul className="space-y-2">
                  {activeData.examples.map((ex, i) => (
                    <li key={i} className="flex items-center gap-2 text-slate-700 bg-white/50 p-2 rounded-lg border border-slate-200/50">
                      <div className="w-1.5 h-1.5 bg-slate-400 rounded-full" />
                      {ex}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="mt-8 p-4 bg-white/60 rounded-xl border border-white/50">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-slate-500 mt-0.5" />
                <p className="text-sm text-slate-600 italic">
                  Note: Determination requires matching your device to a specific Japanese Medical Device Nomenclature (JMDN) code. Incorrect JMDN selection is a common cause for delay.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Classification;