import React, { useState } from 'react';
import { comprehensiveQuestions } from '../content';
import { ChevronDown, HelpCircle } from 'lucide-react';

const Quiz: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <div id="checklist" className="py-12">
      <div className="mb-10 text-center">
        <span className="bg-rose-100 text-rose-700 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider mb-2 inline-block">
          Self-Assessment
        </span>
        <h2 className="text-3xl font-bold text-slate-900">20 Comprehensive Follow-up Questions</h2>
        <p className="text-slate-600 mt-3 max-w-2xl mx-auto">
          Before submitting your application to the PMDA or an RCB, ensure you can answer these critical questions about your device and organizational readiness.
        </p>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 max-w-6xl mx-auto">
        {comprehensiveQuestions.map((item, idx) => (
          <div 
            key={item.id} 
            className={`border rounded-xl transition-all duration-300 overflow-hidden ${
              openIndex === idx ? 'border-rose-200 bg-rose-50/30 shadow-sm' : 'border-slate-200 bg-white'
            }`}
          >
            <button
              onClick={() => toggle(idx)}
              className="w-full flex items-start justify-between p-5 text-left focus:outline-none"
            >
              <div className="flex gap-3">
                <span className={`flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-full text-xs font-bold mt-0.5 ${
                  openIndex === idx ? 'bg-rose-500 text-white' : 'bg-slate-200 text-slate-600'
                }`}>
                  {item.id}
                </span>
                <span className={`font-medium ${openIndex === idx ? 'text-rose-900' : 'text-slate-700'}`}>
                  {item.question}
                </span>
              </div>
              <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform duration-300 flex-shrink-0 ml-2 ${openIndex === idx ? 'rotate-180' : ''}`} />
            </button>
            
            <div 
              className={`overflow-hidden transition-all duration-300 ${
                openIndex === idx ? 'max-h-40 opacity-100' : 'max-h-0 opacity-0'
              }`}
            >
              <div className="px-5 pb-5 ml-9 mr-5">
                <div className="flex items-start gap-2 text-sm text-slate-600 bg-white p-3 rounded-lg border border-rose-100">
                  <HelpCircle className="w-4 h-4 text-rose-400 mt-0.5 flex-shrink-0" />
                  <p>{item.context}</p>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Quiz;