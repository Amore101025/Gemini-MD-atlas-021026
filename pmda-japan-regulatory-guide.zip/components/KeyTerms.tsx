import React from 'react';
import { Book, Globe, Shield, Scale } from 'lucide-react';

const KeyTerms: React.FC = () => {
  return (
    <div className="py-12 bg-slate-100 rounded-3xl my-12 px-6 md:px-12">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900">Critical Concepts</h2>
        <p className="text-slate-600 mt-2">Unlike the EU MDR, Japan has unique structural requirements.</p>
      </div>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex gap-4">
          <div className="p-3 bg-blue-50 rounded-lg h-fit text-blue-600">
            <Globe className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-lg">MAH (Marketing Authorization Holder)</h3>
            <p className="text-sm text-slate-600 mt-2">
              A company in Japan licensed to import and sell medical devices. They hold the final legal liability for the product. If you have no office in Japan, you must appoint a DMAH (Designated MAH).
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex gap-4">
          <div className="p-3 bg-emerald-50 rounded-lg h-fit text-emerald-600">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-lg">MHLW Ordinance 169</h3>
            <p className="text-sm text-slate-600 mt-2">
              Japan's QMS standard. While based on ISO 13485, it has additional requirements regarding document retention, infrastructure, and the relationship between the Manufacturer and the MAH.
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex gap-4">
          <div className="p-3 bg-purple-50 rounded-lg h-fit text-purple-600">
            <Book className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-lg">Package Insert</h3>
            <p className="text-sm text-slate-600 mt-2">
              The Japanese Instructions for Use (IFU). It is a strictly regulated legal document. Deviations from the approved Package Insert can result in product recall.
            </p>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex gap-4">
          <div className="p-3 bg-orange-50 rounded-lg h-fit text-orange-600">
            <Scale className="w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-lg">GVP (Good Vigilance Practice)</h3>
            <p className="text-sm text-slate-600 mt-2">
              Requires the MAH to proactively collect safety information from the manufacturer and the market. It is stricter than standard post-market surveillance.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default KeyTerms;