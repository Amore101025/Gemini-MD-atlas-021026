import React from 'react';
import Hero from './components/Hero';
import Classification from './components/Classification';
import ProcessTimeline from './components/ProcessTimeline';
import KeyTerms from './components/KeyTerms';
import Quiz from './components/Quiz';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-slate-50 selection:bg-rose-200 selection:text-rose-900">
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <span className="font-bold text-xl text-slate-900 tracking-tight">PMDA<span className="text-rose-600">.Guide</span></span>
            </div>
            <div className="flex items-center space-x-8 hidden sm:flex">
              <a href="#classifications" className="text-sm font-medium text-slate-600 hover:text-rose-600 transition-colors">Classifications</a>
              <a href="#process" className="text-sm font-medium text-slate-600 hover:text-rose-600 transition-colors">Process</a>
              <a href="#checklist" className="text-sm font-medium text-slate-600 hover:text-rose-600 transition-colors">Checklist</a>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12 space-y-8">
        <Hero />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-3">
            <Classification />
          </div>
        </div>

        <div id="process" className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
            <ProcessTimeline />
        </div>

        <KeyTerms />

        <Quiz />
      </main>

      <Footer />
    </div>
  );
};

export default App;