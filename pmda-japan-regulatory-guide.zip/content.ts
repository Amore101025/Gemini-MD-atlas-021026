import { RiskClass, ClassificationData, ProcessStep, QuestionItem } from './types';

export const classificationData: ClassificationData[] = [
  {
    id: 'c1',
    className: RiskClass.I,
    riskLevel: 'Low Risk',
    approvalType: 'Todokede (Notification)',
    examples: ['X-ray film', 'Surgical knives', 'External diagnostics'],
    agency: 'PMDA (Notification only)',
    color: 'bg-emerald-100 border-emerald-500 text-emerald-800'
  },
  {
    id: 'c2',
    className: RiskClass.II,
    riskLevel: 'Medium Risk',
    approvalType: 'Ninsho (Pre-market Certification)',
    examples: ['MRI', 'Ultrasound', 'Catheters'],
    agency: 'RCB (Registered Certification Body)',
    color: 'bg-blue-100 border-blue-500 text-blue-800'
  },
  {
    id: 'c3',
    className: RiskClass.III,
    riskLevel: 'High Risk',
    approvalType: 'Shonin (Pre-market Approval)',
    examples: ['Artificial bones', 'Dialyzers', 'Pacemakers (some)'],
    agency: 'PMDA & MHLW',
    color: 'bg-orange-100 border-orange-500 text-orange-800'
  },
  {
    id: 'c4',
    className: RiskClass.IV,
    riskLevel: 'Hightest Risk',
    approvalType: 'Shonin (Pre-market Approval)',
    examples: ['Pacemakers', 'Heart valves', 'Absorbable stents'],
    agency: 'PMDA & MHLW',
    color: 'bg-red-100 border-red-500 text-red-800'
  }
];

export const processSteps: ProcessStep[] = [
  {
    title: "Appoint MAH/DMAH",
    description: "Foreign manufacturers must appoint a Marketing Authorization Holder (MAH) or Designated MAH (DMAH) located in Japan to manage compliance and safety.",
    iconName: "UserCheck"
  },
  {
    title: "Determine Classification",
    description: "Identify the JMDN code and risk classification (I, II, III, or IV) to determine the regulatory pathway (Notification, Certification, or Approval).",
    iconName: "FileSearch"
  },
  {
    title: "QMS Compliance",
    description: "Ensure your Quality Management System meets MHLW Ordinance No. 169, which is based on ISO 13485 with specific Japanese deviations.",
    iconName: "ShieldCheck"
  },
  {
    title: "Submission",
    description: "Submit application to PMDA (for Approval) or an RCB (for Certification). For Class I, simply notify the PMDA.",
    iconName: "Send"
  },
  {
    title: "Review & Audit",
    description: "Undergo technical documentation review and QMS audit. The PMDA or RCB will assess safety, efficacy, and quality.",
    iconName: "Search"
  },
  {
    title: "Market Launch",
    description: "Once certified/approved, reimbursement coverage is applied for, and the product can be placed on the Japanese market.",
    iconName: "Rocket"
  }
];

export const comprehensiveQuestions: QuestionItem[] = [
  { id: 1, question: "Does our device have a valid JMDN code?", context: "Japan Medical Device Nomenclature (JMDN) determines the classification and assessment route." },
  { id: 2, question: "Is our current MAH/DMAH capable of handling post-market surveillance (GVP) strictly?", context: "Japan requires proactive safety monitoring, not just reactive reporting." },
  { id: 3, question: "Have we conducted a gap analysis between ISO 13485:2016 and MHLW Ordinance 169?", context: "Ordinance 169 has specific requirements regarding document retention and MAH communication." },
  { id: 4, question: "Is the device classified as a 'Specified Highly Controlled Medical Device'?", context: "This affects whether you need PMDA approval or if an RCB can certify it (rare for Class III)." },
  { id: 5, question: "Do we have foreign clinical data, and will the PMDA accept it?", context: "The PMDA may require a 'Clinical Evaluation Report' bridging foreign data to the Japanese population." },
  { id: 6, question: "Are all manufacturing sites (domestic and foreign) registered with the MHLW?", context: "Foreign Manufacturer Registration (FMR) is mandatory for all production facilities." },
  { id: 7, question: "How will we manage labeling translations and 'Package Inserts'?", context: "Japanese labeling is strict. The Package Insert is a legal document." },
  { id: 8, question: "Is our reimbursement strategy aligned with the approval timeline?", context: "Obtaining approval does not guarantee insurance reimbursement (NHI price)." },
  { id: 9, question: "Does the device contain biological ingredients?", context: "If yes, stricter regulations regarding biological origin and safety apply." },
  { id: 10, question: "Who controls the technical file—us or the MAH?", context: "Ownership of the approval (Shonin) usually sits with the MAH unless a DMAH is used." },
  { id: 11, question: "Have we accounted for the QMS audit timeline in our launch plan?", context: "PMDA/RCB QMS audits can be a bottleneck in the timeline." },
  { id: 12, question: "Are there associated consumables or software that need separate registration?", context: "Accessories and SaMD (Software as a Medical Device) may require their own approvals." },
  { id: 13, question: "What is our plan for annual reporting requirements?", context: "MAHs must submit annual reports on the status of the device marketing." },
  { id: 14, question: "Do we have a system for 'Near Miss' reporting?", context: "Japan's GVP ordinance requires tracking potential hazards, not just actual adverse events." },
  { id: 15, question: "Is our software developed according to IEC 62304 and JIS T 2304?", context: "Cybersecurity and software life-cycle standards are heavily scrutinized." },
  { id: 16, question: "If we change the manufacturing site, how does that affect our approval?", context: "Change notifications (Partial Change Application) can be costly and time-consuming." },
  { id: 17, question: "Are we prepared for a potential PMDA on-site inspection?", context: "For high-risk devices, the PMDA may inspect the foreign factory physically." },
  { id: 18, question: "Does the product definition differ between the EU/FDA and Japan?", context: "Sometimes a 'device' elsewhere is a 'drug' or 'combination product' in Japan." },
  { id: 19, question: "What is the expiration date of our certification?", context: "Most certifications/approvals are valid indefinitely, but QMS certificates expire every 5 years." },
  { id: 20, question: "Do we have a backup MAH strategy?", context: "Switching MAHs is administratively complex; choosing the right partner initially is critical." },
];
