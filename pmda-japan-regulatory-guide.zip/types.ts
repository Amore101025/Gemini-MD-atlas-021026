import { LucideIcon } from 'lucide-react';

export enum RiskClass {
  I = "Class I",
  II = "Class II",
  III = "Class III",
  IV = "Class IV"
}

export interface ClassificationData {
  id: string;
  className: RiskClass;
  riskLevel: string;
  approvalType: string;
  examples: string[];
  agency: string;
  color: string;
}

export interface ProcessStep {
  title: string;
  description: string;
  iconName: string; 
}

export interface FAQItem {
  question: string;
  answer: string;
  category: 'General' | 'QMS' | 'MAH' | 'Clinical';
}

export interface QuestionItem {
  id: number;
  question: string;
  context: string;
}
