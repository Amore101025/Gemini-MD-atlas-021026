# Technical Specification: PMDA Japan Regulatory Guide & AI Note Keeper

**Version:** 1.0.0  
**Date:** October 26, 2023  
**Status:** Production Ready  
**Framework:** React 19 (ESM)  

---

## 1. Executive Summary

The **PMDA Japan Regulatory Guide** is a high-performance, interactive single-page application (SPA) designed to assist medical device manufacturers in navigating the complex landscape of Japan's Pharmaceutical and Medical Device Act (PMD Act). 

Beyond static information dissemination, the application integrates a "WOW UI" concept featuring dynamic, art-inspired theming (20+ styles) and a sophisticated **AI Note Keeper**. This AI module utilizes the Google Gemini API to provide real-time summarization, translation, keyword extraction, and conversational assistance regarding regulatory compliance.

The system is built to be serverless, utilizing client-side rendering with React, formatted with Tailwind CSS, and relying on the Google GenAI SDK for intelligence. It supports full internationalization (English/Traditional Chinese).

---

## 2. System Architecture

### 2.1 High-Level Overview

The application follows a modular, component-based architecture typical of modern React applications. However, it diverges from standard bundling (like Webpack) by using ES Modules via `importmap` for direct browser execution without a complex build step, enhancing portability and transparency.

*   **Presentation Layer:** React 19 + Tailwind CSS (via CDN).
*   **Logic Layer:** TypeScript (transpiled/executed via ESM support).
*   **Data Layer:** Static content dictionaries (`content.ts`) and local component state.
*   **Intelligence Layer:** Google Gemini API (`@google/genai` SDK).

### 2.2 Directory Structure

```text
/
├── index.html          # Entry point, Import Maps, Polyfills
├── index.tsx           # React DOM Root mounter
├── App.tsx             # Main State Controller (Theme/Lang/Layout)
├── types.ts            # TypeScript Interfaces and Enums
├── content.ts          # Static Data (EN/ZH translations)
├── constants.ts        # Configuration (Painter Styles, AI Prompts)
├── components/         # UI Components
│   ├── Hero.tsx        # Landing section
│   ├── Classification.tsx # Interactive Tabs
│   ├── ProcessTimeline.tsx # Vertical Timeline
│   ├── AINoteKeeper.tsx   # Core AI Logic
│   ├── KeyTerms.tsx    # Grid Layout
│   ├── Quiz.tsx        # Accordion Logic
│   └── Footer.tsx      # Static Footer
└── metadata.json       # App Metadata
```

---

## 3. Frontend Architecture & State Management

### 3.1 Global State Strategy (`App.tsx`)

The root `App` component serves as the "Source of Truth" for the application's global context, managing three primary state vectors:

1.  **Language State (`lang`):** A strict typed string literal `'en' | 'zh'`. Toggling this triggers a cascade update across all child components, forcing a re-render with content fetched from `content.ts`.
2.  **Theme State (`currentStyle`):** An object of type `PainterStyle`. This is central to the "WOW UI." Changing this state instantly updates the CSS variables, background gradients, text colors, and border styles across the entire DOM tree.
3.  **Animation State (`isJackpotSpinning`):** Manages the "Jackpot" UI interaction, preventing re-triggering while an animation cycle is active.

### 3.2 Component Props Pattern

To maintain purity and predictability, styles and language settings are passed down via props. This allows purely presentational components (like `Hero` or `Footer`) to remain stateless regarding the global theme, only rendering what they are given.

**Example Prop Interface:**
```typescript
interface ComponentProps {
  style: PainterStyle; // Contains colors, fonts, backgrounds
  lang: 'en' | 'zh';   // Determines text content
}
```

---

## 4. "WOW UI" Design System

The User Interface is designed to break the monotony of regulatory reading. It employs a dynamic styling engine defined in `constants.ts`.

### 4.1 The `PainterStyle` Interface

Instead of standard CSS classes for theming (e.g., `.dark-mode`), the application uses a Configuration Object pattern. Each style is defined as a `PainterStyle` object:

*   **`appBg`**: Defines the global background. This supports complex CSS properties like `linear-gradient`, solid hex codes, or even image references.
*   **`cardBg`**: Controls the opacity and color of content containers. We utilize RGBA values (e.g., `rgba(255, 255, 255, 0.9)`) to create "Glassmorphism" (backdrop-blur) effects that overlay the `appBg`.
*   **`accentColor`**: A high-contrast color used for buttons, active tabs, and highlights.
*   **`fontClass`**: Optional overrides for typography (e.g., switching to Serif fonts for "Van Gogh" or "Rembrandt" styles).

### 4.2 The Jackpot Mechanism

The style switcher is gamified.
*   **Logic:** A `setInterval` loop runs for a fixed duration (20 cycles), randomly selecting a style from the `PAINTER_STYLES` array every 100ms.
*   **Performance:** React's reconciliation engine handles these rapid state changes efficiently, creating a "slot machine" visual effect where the entire website morphs colors rapidly before settling on the winner.

### 4.3 Responsive Design

*   **Grid Systems:** `Classification` and `KeyTerms` use `grid-cols-1` on mobile to `grid-cols-2/3` on desktop.
*   **Timeline:** The `ProcessTimeline` component features a central vertical line that appears only on `md` screens and up. The flex direction alternates (`flex-row` vs `flex-row-reverse`) to create a zig-zag pattern on desktop, collapsing to a linear vertical stack on mobile.

---

## 5. AI Integration: The Note Keeper

The `AINoteKeeper.tsx` component represents the core functional innovation of this application. It transforms the app from a passive reading resource into an active productivity tool.

### 5.1 Google GenAI SDK Implementation

*   **Library:** `@google/genai` (v0.1.0).
*   **Client Initialization:** The client is initialized *lazily* (on demand) and *defensively*.
    *   *Why Lazy?* To prevent application crashes on startup if an API key is missing.
    *   *Why Defensive?* To support both Environment Variable keys (for deployed contexts) and User Input keys (for public demos).

**Key Resolution Logic:**
1.  Check `process.env.API_KEY` (Polyfilled in `index.html` to prevent reference errors).
2.  Check local component state `userApiKey`.
3.  If neither exists, throw a controlled error and prompt the user via UI overlay.

### 5.2 Model Selection

The user can toggle between two models via a dropdown:
1.  **`gemini-3-flash-preview`**: The default. Optimized for speed and low latency. Ideal for formatting, simple summaries, and translations.
2.  **`gemini-3-pro-preview`**: Optimized for reasoning. Ideal for "Gap Analysis" and complex "Chat" queries regarding regulatory nuances.

### 5.3 Features & Prompt Engineering

The application uses "System Instructions" and "Template Injection" to guide the AI.

#### A. Auto-Format & Markdown Transformation
*   **Goal:** Convert raw text into structured Markdown.
*   **Technique:** One-shot prompting.
*   **Prompt:** `Rewrite the following text into organized, clean Markdown. Identify key medical device regulatory terms... and wrap them in a span with color coral...`
*   **Output Processing:** The AI returns Markdown strings. We use `marked` to parse this into HTML.
*   **Sanitization:** The raw HTML is rendered via `dangerouslySetInnerHTML`. *Note: In a production environment with user-generated content shared between users, a sanitizer like DOMPurify would be added here.*

#### B. AI Magic Buttons (`constants.ts`)
The `AI_MAGICS` array defines available operations. Each object contains a `promptTemplate` function.

*   **Summarize:** "Summarize... into concise bullet points."
*   **Translate to JP:** "Translate... into professional Japanese suitable for PMDA submission."
*   **Action Items:** "Extract a checklist..."
*   **Gap Analysis:** "Analyze... for potential regulatory gaps."

#### C. AI Keywords (Dynamic Injection)
*   **UI:** User inputs a keyword and selects a color via HTML5 color picker.
*   **Logic:** The prompt is dynamically constructed: `Identify key terms related to ${keyword}. Wrap them in <span style="color: ${color}">TERM</span>`.
*   **Result:** Visual highlighting within the rendered Markdown note.

#### D. Contextual Chat
The chat window is not just a general chatbot; it is **grounded** in the user's current note.
*   **System Context Injection:**
    ```javascript
    const systemContext = `You are a helpful Japan PMDA Regulatory assistant. 
    The user is asking about this note: \n\n"${markdownOutput || note}"
    \n\nAnswer concisely.`;
    ```
*   **Effect:** The user can ask "What implies a Class III device in this text?" and Gemini analyzes the *specific note content* to answer.

---

## 6. Internationalization (i18n)

The application implements a custom, lightweight i18n solution without external libraries like `react-i18next`.

### 6.1 Content Mapping (`content.ts`)
Two distinct content trees exist: `enContent` and `zhContent`. Both conform to the `ContentMap` interface defined in `types.ts`.

```typescript
const enContent: ContentMap = {
  hero: { titleStart: "Entering...", ... },
  classification: { ... }
};
```

### 6.2 Switching Logic
A helper function `getContent(lang)` returns the appropriate object tree. Components destructure this tree.
*   **Benefit:** Type-safe content. If a key is missing in Chinese, TypeScript will throw a build error.
*   **Performance:** Zero runtime overhead for string lookups.

---

## 7. Data Structures & Types

The application relies on strict TypeScript definitions to ensure data integrity, particularly for the Regulatory Classification logic.

### 7.1 Risk Class Enum
```typescript
export enum RiskClass {
  I = "Class I",
  II = "Class II",
  III = "Class III",
  IV = "Class IV"
}
```

### 7.2 Classification Data
Each regulatory class is defined as an object containing:
*   `approvalType`: (Notification vs Certification vs Approval).
*   `agency`: (PMDA vs RCB).
*   `examples`: Array of strings.
*   `color`: Tailwind class strings for dynamic coloring within the component.

---

## 8. Security & Error Handling

### 8.1 API Key Security
*   **Problem:** In client-side apps, API keys in code are visible.
*   **Solution 1 (Dev/Deployment):** Keys are injected via environment variables (`process.env.API_KEY`).
*   **Solution 2 (Public Demo):** The key is **not** hardcoded. The app provides a UI for the user to input their *own* key temporarily. This key is stored in React state (memory only) and is cleared on refresh.
*   **Polyfill:** A script in `index.html` defines `window.process` if undefined, preventing the app from crashing in environments where Node.js globals are missing.

### 8.2 AI Failure States
Network requests to Gemini are wrapped in `try...catch` blocks.
*   **UI Feedback:** An `isLoading` boolean triggers a loading spinner overlay (`RefreshCw` icon).
*   **Error Feedback:** User-friendly alerts are shown if the API fails (e.g., Quota exceeded, Invalid Key).

### 8.3 Markdown Parsing
The `marked.parse()` function is wrapped in a try-catch block. If parsing fails (e.g., malformed AI output), the app falls back to displaying the raw text to prevent the UI from breaking.

---

## 9. Performance Optimization

1.  **Tailwind JIT:** Styles are generated on the fly via CDN for this implementation, but the class usage is optimized for reusability.
2.  **Memoization (Implicit):** The static content files prevent unnecessary re-fetching of data.
3.  **Vector Graphics:** All icons utilize `lucide-react` (SVG), ensuring sharp rendering at any scale with minimal file size.
4.  **Transition API:** CSS transitions (`transition-all duration-500`) are used instead of heavy JavaScript animation libraries for theme switching, leveraging the GPU.

---

## 10. Future Roadmap & Extensibility

### 10.1 Short Term
*   **Local Storage Persistence:** Save the user's API key (optional) and current Note content to `localStorage` so data isn't lost on refresh.
*   **PDF Export:** Use `jspdf` to allow users to download their AI-generated regulatory summaries.

### 10.2 Long Term
*   **RAG (Retrieval-Augmented Generation):** Upload actual PMDA PDF guidance documents. The AI would then index these documents to answer specific regulatory questions with citations.
*   **Multi-Modal Input:** Allow users to upload images of device labels, and use Gemini Vision to check for compliance with Japanese labeling laws (Package Insert requirements).

---

## 11. Conclusion

The PMDA Regulatory Guide application successfully demonstrates how modern frontend frameworks can be combined with Generative AI to create vertical-specific tools. By abstracting complex regulatory data into interactive UI elements and providing an AI "copilot" for analysis, it significantly reduces the cognitive load for medical device professionals entering the Japanese market.
